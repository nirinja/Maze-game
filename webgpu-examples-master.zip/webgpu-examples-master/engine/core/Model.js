export class Model {

    constructor({
        primitives = [],
    } = {}) {
        this.primitives = primitives;
    }

}
